1. Extract Plex2Hub.exe and the config file for your hub to a folder
2. Rename the config file to config.config (opposed to config.smartthings or config.hubitat)
3. Edit the config file in notepad or any text editior and paste in the config settings from your chosen platforms app
4. Run the program, if you don't get any errors then it's working, if you do then you have done something wrong!

Note this is version 5(ish) - I made some updates to it works on Hubitat, but haven't versioned and haven't removed all the references to SmartThings! (I might do some day if I can be bothered)
